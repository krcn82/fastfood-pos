// Kiosk placeholder
