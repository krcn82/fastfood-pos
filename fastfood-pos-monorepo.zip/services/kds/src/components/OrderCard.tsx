// KDS OrderCard placeholder
