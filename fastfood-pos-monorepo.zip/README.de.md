# Fastfood POS Monorepo

Dies ist das komplette POS-System.
